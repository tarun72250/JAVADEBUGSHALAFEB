package oopII;

public class A_07_StudentClassDemo {

	public static void main(String[] args) {
		
		A_07_StudentClass st = new A_07_StudentClass(101,94.5f);
		st.displayGrade();
		
		A_07_StudentClass st1 = new A_07_StudentClass(101,90.5f);
		st1.displayGrade();
		
		A_07_StudentClass st2 = new A_07_StudentClass(101,70.5f);
		st2.displayGrade();
		
		A_07_StudentClass st3 = new A_07_StudentClass(101,66.5f);
		st3.displayGrade();
		
		A_07_StudentClass st4 = new A_07_StudentClass(101,54.5f);
		st4.displayGrade();
		
		A_07_StudentClass st5 = new A_07_StudentClass(101,44.5f);
		st5.displayGrade();
		
		A_07_StudentClass st6 = new A_07_StudentClass(101,34.5f);
		st6.displayGrade();
	}

}
