package oopII;

public class A_03_BoxDemo {
	
	public static void main(String[]args)
	{
		//calling default cons
		A_03_Box b = new A_03_Box();
		b.calVolume();
		
		//calling parametrized cons
		A_03_Box b1 = new A_03_Box(2,2,2);
		b1.calVolume();
		
		//copying state of b1 object ,
		A_03_Box b2 = b1;
		
		
		//Check refrence equality
		if(b == b1)
		System.out.println("Same");
		else
		System.out.println("Different");
		
		
		if(b1 == b2)
		System.out.println("Same");
		else
		System.out.println("Different");
	
		
	}

}
