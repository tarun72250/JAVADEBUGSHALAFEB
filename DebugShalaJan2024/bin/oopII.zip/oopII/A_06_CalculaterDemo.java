package oopII;

public class A_06_CalculaterDemo {

	public static void main(String[] args) {
		
		A_06_Calculater c = new A_06_Calculater(2,4);
		c.addition();
		c.addition1(2);
		c.subtraction();
		c.multiplication();
		c.division();
		

	}

}
